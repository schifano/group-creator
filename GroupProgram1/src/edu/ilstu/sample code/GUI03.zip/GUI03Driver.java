
package edu.ilstu;
/*
 * Filename: GUI03Driver.java
 * Sep 14, 2013
 * 
 * ULID: jdboomg
 * Course: IT226
 * Instructor: Cathy Holbrook
 */


/**
 * @author John Boomgarden
 * 
 *         This will test the GUI file opener class. 
 * 
 */
public class GUI03Driver
/**
 *  This program creates an instance of the RegistrationGUI.
  */

{
   public static void main(String[] args)
   {
      new RegsitrationGUI();
   }
}